package servlets;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/AddTodoServlet")
public class amit extends HttpServlet {
    private static final long serialVersionUID = 1L;
    

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get user input from the form
        String task = request.getParameter("task");
        String description = request.getParameter("description");
        String dueDate = request.getParameter("dueDate");
        String priority = request.getParameter("priority");
        //Connection connection = connect.getConn();
        // Database connection
        try {
        	Connection connection = connect.getConn();
            // Prepare a CallableStatement to call the AddTodo stored procedure
            CallableStatement callableStatement = connection.prepareCall("{CALL AddTodo(?, ?, ?, ?)}");
            
            // Set the input parameters for the stored procedure
            callableStatement.setString(1, task);
            callableStatement.setString(2, description);
            callableStatement.setString(3, dueDate);
            callableStatement.setString(4, priority);
            
            // Execute the stored procedure
            callableStatement.execute();
            
            // Close the CallableStatement and connection as needed
            callableStatement.close();
            connection.close();
            
            response.sendRedirect("index.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database errors here
        }
    }
}
