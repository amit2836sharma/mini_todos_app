package servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class gettt {
    public static int getTotalTodoCount() throws ClassNotFoundException {
    	
    	Class.forName("com.mysql.cj.jdbc.Driver");
		
        String JDBC_URL = "jdbc:mysql://localhost:3306/todoamit";
        String JDBC_USERNAME = "root";
        String JDBC_PASSWORD = "Admin123#";
        int totalTodos = 0;

        try (
        		Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD)) {
            String sql = "SELECT countt() AS TotalTodos";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                totalTodos = resultSet.getInt("TotalTodos");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return totalTodos;
    }
}
