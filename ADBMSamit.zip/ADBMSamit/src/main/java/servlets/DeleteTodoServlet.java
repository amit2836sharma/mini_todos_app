package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteTodoServlet")
public class DeleteTodoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the task name to delete from the request parameter
        String taskToDelete = request.getParameter("task");

        // Database connection parameters
        String JDBC_URL = "jdbc:mysql://localhost:3306/todoamit";
        String JDBC_USERNAME = "root";
        String JDBC_PASSWORD = "Admin123#";

        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);

            // Create a PreparedStatement for calling the stored procedure
            String sql = "{CALL deletee(?)}";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            // Set the input parameter for the stored procedure
            preparedStatement.setString(1, taskToDelete);

            // Execute the stored procedure
            preparedStatement.executeUpdate();

            // Close resources
            preparedStatement.close();
            connection.close();

            // Redirect back to the todo list page
            response.sendRedirect("displayy.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database errors here
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database Error");
        }
    }
}
